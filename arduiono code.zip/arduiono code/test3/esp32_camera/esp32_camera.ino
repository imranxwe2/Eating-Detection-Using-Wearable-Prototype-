#include <ai-cal_inferencing.h>
#include "edge-impulse-sdk/dsp/image/image.hpp"
#include "esp_camera.h"
#include "esp_heap_caps.h"

/*
 * ============================================================
 * XIAO ESP32-S3 Sense + OV2640/OV3660
 * ============================================================
 */

#define PWDN_GPIO_NUM     -1
#define RESET_GPIO_NUM    -1

#define XCLK_GPIO_NUM     10
#define SIOD_GPIO_NUM     40
#define SIOC_GPIO_NUM     39

#define Y9_GPIO_NUM       48
#define Y8_GPIO_NUM       11
#define Y7_GPIO_NUM       12
#define Y6_GPIO_NUM       14
#define Y5_GPIO_NUM       16
#define Y4_GPIO_NUM       18
#define Y3_GPIO_NUM       17
#define Y2_GPIO_NUM       15

#define VSYNC_GPIO_NUM    38
#define HREF_GPIO_NUM     47
#define PCLK_GPIO_NUM     13


/*
 * ============================================================
 * IMAGE SETTINGS
 * ============================================================
 */

#define EI_CAMERA_RAW_FRAME_BUFFER_COLS  320
#define EI_CAMERA_RAW_FRAME_BUFFER_ROWS  240
#define EI_CAMERA_FRAME_BYTE_SIZE        3


/*
 * ============================================================
 * GLOBAL VARIABLES
 * ============================================================
 */

static bool debug_nn = false;
static bool is_initialised = false;

static uint8_t *snapshot_buf = nullptr;


/*
 * ============================================================
 * CAMERA CONFIGURATION
 * ============================================================
 */

static camera_config_t camera_config = {

    .pin_pwdn       = PWDN_GPIO_NUM,
    .pin_reset      = RESET_GPIO_NUM,

    .pin_xclk       = XCLK_GPIO_NUM,

    .pin_sscb_sda   = SIOD_GPIO_NUM,
    .pin_sscb_scl   = SIOC_GPIO_NUM,

    .pin_d7         = Y9_GPIO_NUM,
    .pin_d6         = Y8_GPIO_NUM,
    .pin_d5         = Y7_GPIO_NUM,
    .pin_d4         = Y6_GPIO_NUM,
    .pin_d3         = Y5_GPIO_NUM,
    .pin_d2         = Y4_GPIO_NUM,
    .pin_d1         = Y3_GPIO_NUM,
    .pin_d0         = Y2_GPIO_NUM,

    .pin_vsync      = VSYNC_GPIO_NUM,
    .pin_href       = HREF_GPIO_NUM,
    .pin_pclk       = PCLK_GPIO_NUM,

    .xclk_freq_hz   = 20000000,

    .ledc_timer     = LEDC_TIMER_0,
    .ledc_channel   = LEDC_CHANNEL_0,

    .pixel_format   = PIXFORMAT_JPEG,

    .frame_size     = FRAMESIZE_QVGA,

    .jpeg_quality   = 12,

    .fb_count       = 1,

    .fb_location    = CAMERA_FB_IN_PSRAM,

    .grab_mode      = CAMERA_GRAB_WHEN_EMPTY
};


/*
 * ============================================================
 * FUNCTION DECLARATIONS
 * ============================================================
 */

bool ei_camera_init(void);

void ei_camera_deinit(void);

bool ei_camera_capture(
    uint32_t img_width,
    uint32_t img_height,
    uint8_t *out_buf
);

static int ei_camera_get_data(
    size_t offset,
    size_t length,
    float *out_ptr
);


/*
 * ============================================================
 * SETUP
 * ============================================================
 */

void setup()
{
    Serial.begin(115200);

    /*
     * Give USB serial time to connect.
     */
    delay(2000);

    Serial.println();
    Serial.println();
    Serial.println("========================================");
    Serial.println(" Edge Impulse Inferencing Demo");
    Serial.println(" XIAO ESP32-S3 Sense");
    Serial.println(" Camera test");
    Serial.println("========================================");

    /*
     * Check PSRAM before doing anything else.
     */
    Serial.println("Checking PSRAM...");

    if (psramFound()) {
        Serial.println("PSRAM: FOUND");

        Serial.printf(
            "PSRAM size: %u bytes\n",
            ESP.getPsramSize()
        );

        Serial.printf(
            "Free PSRAM: %u bytes\n",
            ESP.getFreePsram()
        );
    }
    else {
        Serial.println("ERROR: PSRAM NOT FOUND!");
        Serial.println("Stopping.");
        return;
    }


    /*
     * Camera initialization.
     */
    Serial.println();
    Serial.println("Initializing camera...");

    if (!ei_camera_init()) {

        Serial.println(
            "ERROR: Camera initialization failed!"
        );

        return;
    }


    Serial.println(
        "Camera initialized successfully."
    );


    /*
     * Give the camera a moment.
     */
    delay(1000);


    Serial.println();
    Serial.println(
        "Starting continuous inference in 2 seconds..."
    );

    delay(2000);

    Serial.println(
        "Entering inference loop..."
    );
}


/*
 * ============================================================
 * LOOP
 * ============================================================
 */

void loop()
{
    if (!is_initialised) {
        delay(1000);
        return;
    }


    if (ei_sleep(5) != EI_IMPULSE_OK) {
        return;
    }


    /*
     * Allocate RGB888 image buffer.
     *
     * 320 x 240 x 3 = 230400 bytes
     *
     * Put it in PSRAM.
     */
    snapshot_buf = (uint8_t *)heap_caps_malloc(
        EI_CAMERA_RAW_FRAME_BUFFER_COLS *
        EI_CAMERA_RAW_FRAME_BUFFER_ROWS *
        EI_CAMERA_FRAME_BYTE_SIZE,
        MALLOC_CAP_SPIRAM
    );


    if (snapshot_buf == nullptr) {

        ei_printf(
            "ERR: Failed to allocate snapshot buffer!\n"
        );

        Serial.printf(
            "Free PSRAM: %u\n",
            ESP.getFreePsram()
        );

        return;
    }


    /*
     * Create Edge Impulse signal.
     */
    ei::signal_t signal;

    signal.total_length =
        EI_CLASSIFIER_INPUT_WIDTH *
        EI_CLASSIFIER_INPUT_HEIGHT;

    signal.get_data =
        &ei_camera_get_data;


    /*
     * Capture image.
     */
    Serial.println("Capturing image...");

    if (!ei_camera_capture(
            EI_CLASSIFIER_INPUT_WIDTH,
            EI_CLASSIFIER_INPUT_HEIGHT,
            snapshot_buf
        )) {

        ei_printf(
            "ERR: Failed to capture image\n"
        );

        free(snapshot_buf);
        snapshot_buf = nullptr;

        return;
    }


    Serial.println("Image captured.");
    Serial.println("Running classifier...");


    /*
     * Run Edge Impulse classifier.
     */
    ei_impulse_result_t result = { 0 };


    EI_IMPULSE_ERROR err =
        run_classifier(
            &signal,
            &result,
            debug_nn
        );


    if (err != EI_IMPULSE_OK) {

        ei_printf(
            "ERR: Failed to run classifier (%d)\n",
            err
        );

        free(snapshot_buf);
        snapshot_buf = nullptr;

        return;
    }


    /*
     * Print timing.
     */
    ei_printf(
        "\nPredictions "
        "(DSP: %d ms, Classification: %d ms, Anomaly: %d ms):\n",
        result.timing.dsp,
        result.timing.classification,
        result.timing.anomaly
    );


    /*
     * Object detection.
     */
#if EI_CLASSIFIER_OBJECT_DETECTION == 1

    ei_printf(
        "Object detection bounding boxes:\n"
    );

    for (
        uint32_t i = 0;
        i < result.bounding_boxes_count;
        i++
    ) {

        ei_impulse_result_bounding_box_t bb =
            result.bounding_boxes[i];

        if (bb.value == 0) {
            continue;
        }

        ei_printf(
            "  %s (%.5f) "
            "[x: %u, y: %u, width: %u, height: %u]\n",

            bb.label,
            bb.value,
            bb.x,
            bb.y,
            bb.width,
            bb.height
        );
    }


#else

    /*
     * Classification.
     */
    ei_printf("Predictions:\n");

    for (
        uint16_t i = 0;
        i < EI_CLASSIFIER_LABEL_COUNT;
        i++
    ) {

        ei_printf(
            "  %s: %.5f\n",

            ei_classifier_inferencing_categories[i],

            result.classification[i].value
        );
    }

#endif


    /*
     * Anomaly.
     */
#if EI_CLASSIFIER_HAS_ANOMALY

    ei_printf(
        "Anomaly prediction: %.3f\n",
        result.anomaly
    );

#endif


    /*
     * Visual anomaly.
     */
#if EI_CLASSIFIER_HAS_VISUAL_ANOMALY

    ei_printf(
        "Visual anomalies:\n"
    );

    for (
        uint32_t i = 0;
        i < result.visual_ad_count;
        i++
    ) {

        ei_impulse_result_bounding_box_t bb =
            result.visual_ad_grid_cells[i];

        if (bb.value == 0) {
            continue;
        }

        ei_printf(
            "  %s (%.5f) "
            "[x: %u, y: %u, width: %u, height: %u]\n",

            bb.label,
            bb.value,
            bb.x,
            bb.y,
            bb.width,
            bb.height
        );
    }

#endif


    /*
     * Free image buffer.
     */
    free(snapshot_buf);

    snapshot_buf = nullptr;

    Serial.println();
}


/*
 * ============================================================
 * CAMERA INITIALIZATION
 * ============================================================
 */

bool ei_camera_init(void)
{
    if (is_initialised) {
        return true;
    }


    Serial.println(
        "Calling esp_camera_init()..."
    );


    esp_err_t err =
        esp_camera_init(&camera_config);


    if (err != ESP_OK) {

        Serial.printf(
            "Camera init failed with error 0x%x\n",
            err
        );

        return false;
    }


    Serial.println(
        "esp_camera_init() returned OK."
    );


    /*
     * Get camera sensor.
     */
    sensor_t *s =
        esp_camera_sensor_get();


    /*
     * IMPORTANT:
     * Protect against NULL sensor pointer.
     */
    if (s == nullptr) {

        Serial.println(
            "ERROR: esp_camera_sensor_get() returned NULL!"
        );

        esp_camera_deinit();

        return false;
    }


    Serial.printf(
        "Camera sensor PID: 0x%04X\n",
        s->id.PID
    );


    /*
     * Configure OV3660.
     */
    if (s->id.PID == OV3660_PID) {

        Serial.println(
            "OV3660 detected."
        );

        s->set_vflip(s, 1);

        s->set_brightness(s, 1);

        s->set_saturation(s, 0);
    }


    /*
     * Configure OV2640 if used.
     */
    else if (s->id.PID == OV2640_PID) {

        Serial.println(
            "OV2640 detected."
        );

        s->set_vflip(s, 1);

        s->set_hmirror(s, 0);
    }


    else {

        Serial.printf(
            "WARNING: Unknown camera PID: 0x%04X\n",
            s->id.PID
        );
    }


    /*
     * Keep camera at QVGA.
     */
    s->set_framesize(
        s,
        FRAMESIZE_QVGA
    );


    is_initialised = true;

    Serial.println(
        "Camera initialization OK."
    );

    return true;
}


/*
 * ============================================================
 * CAMERA DEINITIALIZATION
 * ============================================================
 */

void ei_camera_deinit(void)
{
    if (!is_initialised) {
        return;
    }


    esp_err_t err =
        esp_camera_deinit();


    if (err != ESP_OK) {

        ei_printf(
            "Camera deinit failed: 0x%x\n",
            err
        );

        return;
    }


    is_initialised = false;

    Serial.println(
        "Camera deinitialized."
    );
}


/*
 * ============================================================
 * CAMERA CAPTURE
 * ============================================================
 */

bool ei_camera_capture(
    uint32_t img_width,
    uint32_t img_height,
    uint8_t *out_buf
)
{
    if (!is_initialised) {

        ei_printf(
            "ERR: Camera is not initialized\n"
        );

        return false;
    }


    if (out_buf == nullptr) {

        ei_printf(
            "ERR: Output buffer is NULL\n"
        );

        return false;
    }


    /*
     * Capture JPEG frame.
     */
    camera_fb_t *fb =
        esp_camera_fb_get();


    if (fb == nullptr) {

        ei_printf(
            "ERR: Camera capture failed\n"
        );

        return false;
    }


    /*
     * Convert JPEG -> RGB888.
     *
     * IMPORTANT:
     * Write directly to snapshot_buf.
     */
    bool converted =
        fmt2rgb888(
            fb->buf,
            fb->len,
            PIXFORMAT_JPEG,
            out_buf
        );


    /*
     * Return camera framebuffer.
     */
    esp_camera_fb_return(fb);


    if (!converted) {

        ei_printf(
            "ERR: JPEG -> RGB888 conversion failed\n"
        );

        return false;
    }


    /*
     * Resize if the Edge Impulse model does not use
     * 320 x 240.
     */
    if (
        img_width != EI_CAMERA_RAW_FRAME_BUFFER_COLS ||
        img_height != EI_CAMERA_RAW_FRAME_BUFFER_ROWS
    ) {

        size_t resized_size =
            img_width *
            img_height *
            EI_CAMERA_FRAME_BYTE_SIZE;


        uint8_t *resized_buf =
            (uint8_t *)heap_caps_malloc(
                resized_size,
                MALLOC_CAP_SPIRAM
            );


        if (resized_buf == nullptr) {

            ei_printf(
                "ERR: Failed to allocate resize buffer\n"
            );

            return false;
        }


        /*
         * Input = out_buf
         * Output = resized_buf
         *
         * Do NOT use the same buffer for both.
         */
        ei::image::processing::crop_and_interpolate_rgb888(

            resized_buf,

            EI_CAMERA_RAW_FRAME_BUFFER_COLS,
            EI_CAMERA_RAW_FRAME_BUFFER_ROWS,

            out_buf,

            img_width,
            img_height
        );


        /*
         * Copy resized image back.
         */
        memcpy(
            out_buf,
            resized_buf,
            resized_size
        );


        free(resized_buf);
    }


    return true;
}


/*
 * ============================================================
 * EDGE IMPULSE DATA CALLBACK
 * ============================================================
 */

static int ei_camera_get_data(
    size_t offset,
    size_t length,
    float *out_ptr
)
{
    if (snapshot_buf == nullptr) {
        return -1;
    }


    size_t pixel_ix =
        offset * 3;

    size_t pixels_left =
        length;

    size_t out_ptr_ix =
        0;


    while (pixels_left != 0) {

        /*
         * Convert RGB888 to Edge Impulse format.
         */
        out_ptr[out_ptr_ix] =
            (
                (snapshot_buf[pixel_ix + 2] << 16) |
                (snapshot_buf[pixel_ix + 1] << 8) |
                snapshot_buf[pixel_ix]
            );


        out_ptr_ix++;

        pixel_ix += 3;

        pixels_left--;
    }


    return 0;
}


/*
 * ============================================================
 * MODEL CHECK
 * ============================================================
 */

#if !defined(EI_CLASSIFIER_SENSOR) || \
    EI_CLASSIFIER_SENSOR != EI_CLASSIFIER_SENSOR_CAMERA

#error "Invalid model for current sensor"

#endif